# Bottle detection > 2024-02-13 12:01pm
https://universe.roboflow.com/dstu-dfliv/bottle-detection-o85n0

Provided by a Roboflow user
License: CC BY 4.0

